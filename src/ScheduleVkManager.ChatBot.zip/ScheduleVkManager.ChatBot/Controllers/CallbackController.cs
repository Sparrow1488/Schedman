﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ScheduleVkManager.ChatBot.Entities;
using System;
using System.Threading.Tasks;
using VkNet.Abstractions;
using VkNet.Model;
using VkNet.Model.RequestParams;
using VkNet.Utils;

namespace ScheduleVkManager.ChatBot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CallbackController : ControllerBase
    {
        public CallbackController(IVkApi api, IConfiguration configuration) {
            _api = api;
            _config = configuration;
        }

        private readonly IVkApi _api;
        private readonly IConfiguration _config;
        private VkCallback _lastRequest;

        [HttpPost]
        public IActionResult Callback([FromForm] VkCallback vkRequest)
        {
            IActionResult response = Ok(_config["VkConfig:Confirmation"]);

            if (vkRequest.Type.Contains("confirmation")) {
                response = Ok(_config["VkConfig:Confirmation"]);
            }
            else if (vkRequest.Type.Contains("message_new")) {
                var message = Message.FromJson(new VkResponse(vkRequest.Object));
                _api.Messages.Send(new MessagesSendParams(){
                    RandomId = new Random().Next(int.MaxValue),
                    PeerId = message.PeerId.Value,
                    Message = "Hello, user!"
                });
                response = Ok("ok");
            }
            return response;
        }

        [HttpPost("testpost")]
        public IActionResult OnPostCallBack()
        {
            return Ok(_lastRequest);
        }

        [HttpGet("status")]
        public IActionResult GetStatus()
        {
            return new JsonResult(new
            {
                status = "ok",
                isAuth = _api.IsAuthorized
            });
        }
    }
}
